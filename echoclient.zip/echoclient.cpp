#include "echoclient.h"
#include <QtCore/QDebug>
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <iostream>

using namespace rapidjson;

QT_USE_NAMESPACE



//! [constructor]
EchoClient::EchoClient(const QUrl &url, bool debug, QObject *parent) :
    QObject(parent),
    m_url(url),
    m_debug(debug)
{
    if (m_debug)
        qDebug() << "WebSocket server:" << url;

    connect(&m_webSocket, &QWebSocket::connected, this, &EchoClient::onConnected);
    connect(&m_webSocket, &QWebSocket::disconnected, this, &EchoClient::closed);
    connect(&m_webSocket, &QWebSocket::textMessageReceived, this, &EchoClient::onTextMessageReceived);
//    connect(&m_webSocket, &QWebSocket::users, this, &EchoClient::onUsers);

    m_webSocket.open(QUrl(url));
}
//! [constructor]

//! [onConnected]
void EchoClient::onConnected()
{
    if (m_debug)
        qDebug() << "WebSocket connected";
   connect(&m_webSocket, &QWebSocket::textMessageReceived,
            this, &EchoClient::onTextMessageReceived);
    m_webSocket.sendTextMessage(QStringLiteral("Hello, world!"));
    QByteArray bytes = m_name.toUtf8();
       std::string nickName(bytes.data(),bytes.length());
       _io->socket()->emit("add user", nickName);
}
//! [onConnected]

void EchoClient::onTextMessageReceived(QString message)
{
   if (m_debug)
        qDebug() << "Message received:" << message;
    m_webSocket.close();
}
//void EchoClient::onUsers(QJsonObject user)
//{
//        qDebug() << "User:" << user;
//}

