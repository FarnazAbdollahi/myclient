#ifndef ECHOCLIENT_H
#define ECHOCLIENT_H

#include <QtCore/QObject>
#include <QtWebSockets/QWebSocket>

class EchoClient : public QObject
{
    Q_OBJECT
public:
    explicit EchoClient(const QUrl &url, bool debug = false, QObject *parent = nullptr);

    // initiate the connection - the url address to be set after the completion of the protocol head start
    bool startConnect();

    // Disconnect
    void disconnect();

    // Set the URL for the link
    void setConnectUrl(QString val);

    // Get the current status
    /*webSocketState getCurrentState();*/



Q_SIGNALS:
    void closed();
    void userConnected();
    void users();

private Q_SLOTS:

    // connection succeeded
    void onConnected();

    // Disconnect
    void onDisconnected();

    // received the agreement
    void onTextMessageReceived(QString message);

    void onUserConnected();

    void onUsers();

private:
    /*webSocketState m_webSocketState;*/ // websocket state
    QWebSocket m_webSocket; // websocket client
    QUrl m_url; // URL address
    bool m_debug;
};

#endif // ECHOCLIENT_H
